export class Scopes {
  constructor(public ScopeId: number, public ScopeTitle: string) {}
}

export class Guesses {
  constructor(public ScopeId: number, public GuessTitle: string) {}
}
