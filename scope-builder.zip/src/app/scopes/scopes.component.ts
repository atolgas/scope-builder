import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-scopes',
  templateUrl: './scopes.component.html',
  styleUrls: ['./scopes.component.css']
})
export class ScopesComponent {
  constructor() {}
}
